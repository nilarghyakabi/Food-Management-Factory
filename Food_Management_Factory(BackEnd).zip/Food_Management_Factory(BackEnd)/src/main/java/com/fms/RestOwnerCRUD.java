package com.fms;

import java.util.List;
import java.util.Scanner;

import com.fms.dao.AddressDAO;
import com.fms.dao.FoodDAO;
import com.fms.dao.RestOwnerDAO;
import com.fms.dao.RestaurantDAO;
import com.fms.entity.Address;
import com.fms.entity.Food;
import com.fms.entity.RestOwner;
import com.fms.entity.Restaurant;

public class RestOwnerCRUD {

	RestOwnerDAO restOwnerDAO = new RestOwnerDAO();
	AddressDAO addDao = new AddressDAO();
	RestaurantDAO restDao = new RestaurantDAO();
	FoodDAO foodDao = new FoodDAO();
	Scanner sc = new Scanner(System.in);
	
	public void createRestOwnerAccount()
	{
		System.out.print("Enter name: ");
		String name = sc.nextLine();
		
		System.out.print("Enter email: ");
		String email = sc.next();
		
		System.out.print("Enter phone: ");
		String phone = sc.next();
		
		System.out.print("Enter password: ");
		String pass = sc.next();
		
		System.out.print("Enter location: ");
		String loc = sc.next();
		
		System.out.print("Enter pin code: ");
		String pin = sc.next();
		
		sc.nextLine();
		System.out.print("Enter state: ");
		String state = sc.nextLine();
		
		System.out.print("Enter country: ");
		String country = sc.nextLine();
		
		Address add = new Address(loc, pin, country, state);
		addDao.saveAddress(add);
		
		RestOwner restOwner = new RestOwner(name, pass, phone, email, country, add);
		restOwnerDAO.saveRestOwnerName(restOwner);
	}
	
	public void addRestaurant(RestOwner restOwner)
	{
		sc.nextLine();
		System.out.print("Enter restaurant name: ");
		String name = sc.nextLine();
		
		System.out.print("Enter registration number: ");
		String regNo = sc.nextLine();
		
		System.out.print("Enter restaurant phone no.: ");
		String phone = sc.next();
		
		System.out.print("Enter location: ");
		String loc = sc.next();
		
		System.out.print("Enter pin code: ");
		String pin = sc.next();
		
		sc.nextLine();
		System.out.print("Enter state: ");
		String state = sc.nextLine();
		
		System.out.print("Enter country: ");
		String country = sc.nextLine();
		
		Address add = new Address(loc, pin, country, state);
		addDao.saveAddress(add);
		
		Restaurant rest = new Restaurant(name, regNo, phone, add);
		restDao.saveRestaurant(rest, restOwner);
		
	}
	
	public void addFood(Restaurant rest)
	{
		System.out.print("Enter food name: ");
		String name = sc.nextLine();
		
		System.out.print("Enter food price: ");
		double price = sc.nextDouble();
		
		sc.nextLine();
		System.out.print("Enter food type: ");
		String type = sc.nextLine();
		
		Food food = new Food(name, price, type);
		foodDao.saveFoodItem(food, rest);
	}
	
	public void viewFoodMenu(Restaurant rest)
	{
		List<Food> foods = foodDao.getFoodFromRestaurant(rest);
		
		System.out.println("  Food Name\t\tPrice\t\tType");
		
		for(Food food: foods)
		{
			System.out.println(" "+food.getFoodName()+"\t\t"+food.getFoodPrice()+"\t\t"+food.getType());
		}
	}
	public RestOwner updateRestOwnerAccount(RestOwner oldRestOwn) {
		System.out.print("Enter name: ");
		String name = sc.nextLine();

		System.out.print("Enter email: ");
		String email = sc.next();

		System.out.print("Enter phone: ");
		String phone = sc.next();


		System.out.print("Enter password: ");
		String pass = sc.next();

		System.out.print("Enter location: ");
		String loc = sc.next();

		System.out.print("Enter pin code: ");
		String pin = sc.next();

		sc.nextLine();
		System.out.print("Enter state: ");
		String state = sc.nextLine();

		System.out.print("Enter country: ");
		String country = sc.nextLine();

		Address add = new Address(loc, pin, country, state);
		addDao.updateAddress(oldRestOwn.getAddress().getAddId(),add);

		RestOwner restaurantOwner = new RestOwner(name, pass, phone, email, country, add);
		return restDao.updateRestaurant(oldRestOwn.getId(), restaurantOwner);

	}
	public void viewRestOwnerProfile(RestOwner restOwner) {
		System.out.println("id: " + restOwner.getId());
		System.out.println("Name: " + restOwner.getName());
		System.out.println("Password: " + restOwner.getPassword());
		System.out.println("Ph No: " + restOwner.getPhone());
		System.out.println("Email: " + restOwner.getEmail());
		System.out.println("Locality: " + restOwner.getAddress().getLocation());
		System.out.println("Country: " + restOwner.getAddress().getCountry());
		System.out.println("State: " + restOwner.getAddress().getState());
		System.out.println("Pin: " + restOwner.getAddress().getPin());
	}
}
