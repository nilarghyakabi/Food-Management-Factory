package com.fms.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Food {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long foodId;
	
	@Column(length = 50, nullable = false)
	private String foodName;
	
	@Column
	private double foodPrice;
	
	@Column(length = 30, nullable = false)
	private String type;
	
	@ManyToOne
	@JoinColumn(name = "restId")
	private Restaurant restaurant;

	public Food(String foodName, double foodPrice, String type) {
		super();
		this.foodName = foodName;
		this.foodPrice = foodPrice;
		this.type = type;
	}
}
