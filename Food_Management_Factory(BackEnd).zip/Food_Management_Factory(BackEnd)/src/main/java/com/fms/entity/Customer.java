package com.fms.entity;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Customer extends User{

	@Column
	private LocalDate dob;
	
	@OneToMany
	@JoinColumn(name = "customerId")
	private List<OrderDetails> orderDetails;

	public Customer(String name, String password, String phone, String email, String role, Address address,
			LocalDate dob) {
		super(name, password, phone, email, role, address);
		this.dob = dob;
	}
	
	
}
