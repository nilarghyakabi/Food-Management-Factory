package com.fms.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class OrderDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long orderId;
	
	@Column
	private LocalDateTime timeOfOrder;
	
	@Column(nullable = false)
	private int quantity;
	
	@Column(nullable = false)
	private double totalPrice;
	
	@ManyToOne
	@JoinColumn(name = "customerId")
	private Customer customer;
	
	@OneToOne
	private Food food;

	public OrderDetails(int quantity, double totalPrice, Customer customer, Food food) {
		super();
		this.quantity = quantity;
		this.totalPrice = totalPrice;
		this.customer = customer;
		this.food = food;
	}
	
	
	
}
