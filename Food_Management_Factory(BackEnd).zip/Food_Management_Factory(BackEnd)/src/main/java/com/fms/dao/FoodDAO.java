package com.fms.dao;

import java.util.List;

import org.hibernate.Session;

import com.fms.entity.Food;
import com.fms.entity.Restaurant;
import com.fms.util.HibernateUtil;



public class FoodDAO {

	public void saveFoodItem(Food food, Restaurant rest) {
		try (Session session = HibernateUtil.getSession()) {
			if (!session.getTransaction().isActive()) {
				session.beginTransaction();
			}

			food.setRestaurant(rest);

			session.save(food);

			session.getTransaction().commit();

			System.out.println("Food Item saved successfully!!");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public List<Food> getFoodFromRestaurant(Restaurant rest)
	{
		try (Session session = HibernateUtil.getSession()) {
		return session.createQuery("from Food where restaurant = :r", Food.class)
				.setParameter("r", rest)
				.getResultList();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
}
